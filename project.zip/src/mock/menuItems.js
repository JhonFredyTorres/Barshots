const menuItems = [
  {
    id: 1,
    name: "Shot Clásico",
    price: 12000,
    image: "https://4tsix0yujj.ufs.sh/f/2vMRHqOYUHc06m4jzyVFtni9pklCcebwvoumN4D1UEQ3aHWZ",
    description: "Nuestro shot tradicional con un toque especial"
  },
  {
    id: 2,
    name: "Shot Especial",
    price: 15000,
    image: "https://4tsix0yujj.ufs.sh/f/2vMRHqOYUHc0h1rWU1uUK73FIu6QMZBiVNxCwz4OT8kREWfS",
    description: "Una explosión de sabores en cada trago"
  },
  {
    id: 3,
    name: "Shot Premium",
    price: 18000,
    image: "https://4tsix0yujj.ufs.sh/f/2vMRHqOYUHc0uPbGyqYvblOpQY7AJg0nTmsBhyINFZ6E3XCU",
    description: "Para los paladares más exigentes"
  }
];

export default menuItems;

// DONE