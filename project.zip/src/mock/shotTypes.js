const shotTypes = [
  { name: "Tequila", color: "#FFD700" },
  { name: "Vodka", color: "#84C4FF" },
  { name: "Whisky", color: "#D2691E" },
  { name: "Ron", color: "#9D00FF" },
  { name: "Ginebra", color: "#E6E6FA" },
  { name: "Fernet", color: "#006B3C" },
  { name: "Cerveza", color: "#FDBB30" },
  { name: "Penitencia", color: "#E61E2A" }
];

export default shotTypes;