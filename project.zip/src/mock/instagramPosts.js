const instagramPosts = [
  {
    id: 1,
    image: "instagram-1.jpg",
    likes: 245,
    comments: 32
  },
  {
    id: 2,
    image: "instagram-2.jpg",
    likes: 189,
    comments: 14
  },
  {
    id: 3,
    image: "instagram-3.jpg",
    likes: 312,
    comments: 45
  },
  {
    id: 4,
    image: "instagram-4.jpg",
    likes: 278,
    comments: 29
  },
  {
    id: 5,
    image: "instagram-5.jpg",
    likes: 156,
    comments: 18
  },
  {
    id: 6,
    image: "instagram-6.jpg",
    likes: 421,
    comments: 53
  }
];

export default instagramPosts;